export type Route = "menu" | "play";
export const ROUTE: { [K in Route]: K } = { menu: "menu", play: "play" };



