// postcss.config.js
export default {
    plugins: {
      "@tailwindcss/postcss": {},  // Tailwind v4 PostCSS plugin
      autoprefixer: {},
    },
  };
  