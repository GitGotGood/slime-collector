export type Rarity = "common" | "uncommon" | "rare" | "epic" | "mythic";

export type Skin = {
  id: string;
  name: string;
  tier: Rarity;
  kind: "solid" | "gradient" | "animated";
  colors: string[];
};

export const SKINS: Record<string, Skin> = {
  green: { id: "green", name: "Green", tier: "common", kind: "solid", colors: ["#22c55e"] },
  mint: { id: "mint", name: "Mint", tier: "common", kind: "solid", colors: ["#4ade80"] },
  blueberry: { id: "blueberry", name: "Blueberry", tier: "common", kind: "solid", colors: ["#60a5fa"] },
  lemon: { id: "lemon", name: "Lemon", tier: "common", kind: "solid", colors: ["#fde047"] },
  cherry: { id: "cherry", name: "Cherry", tier: "common", kind: "solid", colors: ["#fb7185"] },

  slate: { id: "slate", name: "Slate", tier: "uncommon", kind: "solid", colors: ["#94a3b8"] },
  seafoam: { id: "seafoam", name: "Seafoam", tier: "uncommon", kind: "solid", colors: ["#2dd4bf"] },
  grape: { id: "grape", name: "Grape", tier: "uncommon", kind: "solid", colors: ["#a78bfa"] },

  tangerine: { id: "tangerine", name: "Tangerine", tier: "rare", kind: "gradient", colors: ["#fb923c", "#f59e0b"] },
  bubblegum: { id: "bubblegum", name: "Bubblegum", tier: "rare", kind: "gradient", colors: ["#f472b6", "#fbcfe8"] },

  lava: { id: "lava", name: "Lava", tier: "epic", kind: "animated", colors: ["#ef4444", "#f97316", "#fbbf24"] },
  aurora: { id: "aurora", name: "Aurora", tier: "epic", kind: "animated", colors: ["#22d3ee", "#22c55e", "#a78bfa"] },

  nebula: { id: "nebula", name: "Nebula", tier: "mythic", kind: "animated", colors: ["#6d28d9", "#7c3aed", "#0ea5e9"] },
};

export const ALL_SHOP_ITEMS = Object.values(SKINS).map((s) => ({
  id: `skin_${s.id}`,
  type: "skin" as const,
  skin: s.id,
  tier: s.tier,
}));

// Back-compat for older components that still import these:
export const SKIN_PALETTES: Record<string, { fill: string; stroke: string; shine: string; label: string }> = {
  green:  { fill: "#22c55e", stroke: "#065f46", shine: "#bbf7d0", label: "Green" },
  mint:   { fill: "#4ade80", stroke: "#065f46", shine: "#bbf7d0", label: "Mint" },
  blueberry: { fill: "#60a5fa", stroke: "#1e3a8a", shine: "#dbeafe", label: "Blueberry" },
  lemon: { fill: "#fde047", stroke: "#92400e", shine: "#fef9c3", label: "Lemon" },
  cherry: { fill: "#fb7185", stroke: "#7f1d1d", shine: "#fecdd3", label: "Cherry" },
  slate: { fill: "#94a3b8", stroke: "#334155", shine: "#e2e8f0", label: "Slate" },
  seafoam: { fill: "#2dd4bf", stroke: "#134e4a", shine: "#99f6e4", label: "Seafoam" },
  grape: { fill: "#a78bfa", stroke: "#5b21b6", shine: "#e9d5ff", label: "Grape" },
  tangerine: { fill: "#fb923c", stroke: "#7c2d12", shine: "#fed7aa", label: "Tangerine" },
  bubblegum: { fill: "#f472b6", stroke: "#9f1239", shine: "#fbcfe8", label: "Bubblegum" },
  nebula: { fill: "#581c87", stroke: "#3b0764", shine: "#f5d0fe", label: "Nebula" },
};

export const RARITY_PILL: Record<Rarity, string> = {
  common:   "bg-slate-100 text-slate-700 border-slate-200",
  uncommon: "bg-emerald-50 text-emerald-700 border-emerald-200",
  rare:     "bg-sky-50 text-sky-700 border-sky-200",
  epic:     "bg-purple-50 text-purple-700 border-purple-200",
  mythic:   "bg-amber-50 text-amber-700 border-amber-200",
};
